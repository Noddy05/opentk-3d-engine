﻿namespace GameEngine
{
    class MonoBehaviour
    {
        public readonly Window? gameWindow = Program.GetWindow();
    }
}